package lab.session1;

public class SwitchWithString {
    
    public static void main(String[] args) {
        String fruit = "apple";
        switch(fruit) {
            case "apple":
                System.out.println("蘋果");
                break;
            case "banana":
                System.out.println("香蕉");
                break;    
        }
    }
    
}
