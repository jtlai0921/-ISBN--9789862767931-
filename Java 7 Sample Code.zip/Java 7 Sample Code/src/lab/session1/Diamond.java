package lab.session1;
import java.util.*;

public class Diamond {
     public static void main(String[] args) {
         Map<String, Integer> score = new HashMap<>();
         score.put("Chinese", 100);
         score.put("Math", 80);
         score.put("English", 90);
         System.out.println(score);
     }
}
