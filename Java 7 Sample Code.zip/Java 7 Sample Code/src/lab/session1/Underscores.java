package lab.session1;

public class Underscores {
    public static void main(String[] args) {
        int salary = 9_0000_0000;
        int money = 800_000_000;
        int ten = 0b1010;
        
        System.out.println("Salary:" + salary);
        System.out.println("Money:" + money);
        System.out.println("Ten:" + ten);
    }
}
