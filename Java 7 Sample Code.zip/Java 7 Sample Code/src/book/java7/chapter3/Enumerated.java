package book.java7.chapter3;
public class Enumerated {
    public enum Week {Sunday, Monday, Tuesday, Wednesday,
                             Thursday, Friday, Saturday}
    public static void main(String[] args) {
        System.out.println(Week.Sunday);
    }
}

