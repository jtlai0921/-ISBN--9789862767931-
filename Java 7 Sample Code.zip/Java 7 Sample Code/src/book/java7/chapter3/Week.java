package book.java7.chapter3;
public enum Week {Sunday, Monday, Tuesday, Wednesday, Thursday,
Friday, Saturday}

