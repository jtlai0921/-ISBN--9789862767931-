package book.java7.chapter3;
public class MyTest2 {
    MyTest2(String s) {
        System.out.println("Java" + s);
    }
    public static void main(String[] args) {
        MyTest2 t = new MyTest2("7");
    }
}
