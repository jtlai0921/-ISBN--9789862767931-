package book.java7.chapter3;
import static java.lang.System.out;
public class HelloImportStatic {
    public static void main(String[] args) {
        System.out.println("Hello World !");
    }
}
