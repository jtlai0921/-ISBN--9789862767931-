package book.java7.chapter2;

public class SwitchWithString {

    public static void main(String[] args) {
        String name = "Mary";
        switch (name) {
            case "Mary":
                System.out.println("My name is Mary");
                break;
            case "John":
                System.out.println("My name is John");
                break;
        }
        
    }
}

