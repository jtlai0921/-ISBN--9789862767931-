package book.java7.chapter5;
public class ThreadTest3 {
    public static void main(String[] args) {
        HelloThread t1 = new HelloThread();
        HelloThread t2 = new HelloThread();
        t1.setName("T1");
        t2.setName("T2");
        t1.start();
        t2.start();
    }
}

