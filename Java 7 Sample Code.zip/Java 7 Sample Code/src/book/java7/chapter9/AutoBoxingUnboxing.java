package book.java7.chapter9;
public class AutoBoxingUnboxing {
    public static void main(String[] args) {
        Integer numerous = 100;  // auto-boxing
        int x = numerous;  // auto-unboxing
        System.out.println(numerous + x);
    }
}

