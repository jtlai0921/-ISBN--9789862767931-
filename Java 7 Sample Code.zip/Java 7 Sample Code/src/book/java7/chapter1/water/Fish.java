package book.java7.chapter1.water;

public class Fish {
    public static String name = "小金";
    public static String type = "金魚";
    public static String color = "金";
    public static void skill() {
        System.out.println("吐泡泡");
    }
}

