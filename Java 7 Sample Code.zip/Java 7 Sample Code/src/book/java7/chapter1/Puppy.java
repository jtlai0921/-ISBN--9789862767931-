package book.java7.chapter1;

public class Puppy {
    public static String name = "小黃";
    public static String type = "拉布拉多";
    public static String color = "米黃";

    public static void skill() {
        System.out.println("拿報紙與拎拖鞋");        
    }
}
